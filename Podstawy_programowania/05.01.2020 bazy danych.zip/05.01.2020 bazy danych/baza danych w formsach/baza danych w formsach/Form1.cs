﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baza_danych_w_formsach
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "";
            SqlDataReader read= null;
            SqlConnection conn = new SqlConnection(string.Format(@"Data Source=STACJA02\SQLEXPRESS,13; Initial Catalog=test_32; User={0}; Password={1}",login.Text,pass.Text));              //Jeszcze inna metoda - z innego użytkownika (użytkownik ferie_32)      Data Source=STACJA02\SQLEXPRESS,13 - łączy się przez 13 port


            try
            {
                conn.Open();
                label1.Text= string.Format("Prawidłowe połączenie z bazą danych\n");

                sql = "select * from [user]";
                SqlCommand cmd = new SqlCommand(sql, conn);

                read = cmd.ExecuteReader();

                //while (read.Read())         //odczytuje bazę do samego końca
                //{
                //   "Data urodzenia: {0}\nImię: {1}, nazwisko: {2}\n", read[3], read[1], read[2]);//read[numer kolumny]
                //}

            }
            catch (SqlException ex)
            {
                label1.Text =string.Format("Błąd połączenia z bazą danych \n{0}", ex.Message);

            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
                if (read != null)
                {
                    read.Close();
                }
            }
        }
    }
}
