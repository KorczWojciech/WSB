﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace baza_danych
{
    class Program
    {
        static void Main(string[] args)
        {
            string sql;
            SqlDataReader read=null;
            //SqlConnection conn = new SqlConnection(@"Data Source=localhost\SQLEXPRESS; Initial Catalog=test_32; Integrated Security=true");               //Połącznie z bazą danych
            //SqlConnection conn = new SqlConnection(@"Data Source=STACJA02\SQLEXPRESS; Initial Catalog=test_32; Integrated Security=true");                        //inna metoda patrz Data source
            SqlConnection conn = new SqlConnection(@"Data Source=STACJA02\SQLEXPRESS,13; Initial Catalog=test_32; User=ferie_32; Password=ferie_32");              //Jeszcze inna metoda - z innego użytkownika (użytkownik ferie_32)      Data Source=STACJA02\SQLEXPRESS,13 - łączy się przez 13 port


            try
            {
                conn.Open();
                Console.WriteLine("Prawidłowe połączenie z bazą danych\n");

                sql = "select * from [user]";
                SqlCommand cmd = new SqlCommand(sql, conn);

                read = cmd.ExecuteReader();

                while (read.Read())         //odczytuje bazę do samego końca
                {
                    Console.WriteLine("Data urodzenia: {0}\nImię: {1}, nazwisko: {2}\n",read[3], read[1], read[2]);//read[numer kolumny]
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine("Błąd połączenia z bazą danych \n{0}",e.Message);
                
            }
            finally
            {
                if (conn!=null)
                {
                    conn.Close();
                }
                if (read != null)
                {
                    read.Close();
                }
            }
            Console.ReadKey();
        }
    }
}
