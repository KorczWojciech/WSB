﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int licznik = 0;
            string linijka;
            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\student\Desktop\Test1.txt");
            while ((linijka = file.ReadLine()) != null)
            {
                System.Console.WriteLine(linijka);
                licznik++;
            }
            file.Close();
            System.Console.WriteLine("Było {0} linijek", licznik);
            Console.ReadKey();
        }
    }
}
