﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b,wynik;
            Console.WriteLine("Podaj 1. liczbę");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Podaj 2. liczbę");
            b = Convert.ToInt32(Console.ReadLine());
            wynik = a + b;
            Console.WriteLine("Wynik: {0}", wynik);
            Console.ReadKey();
        }
    }
}
