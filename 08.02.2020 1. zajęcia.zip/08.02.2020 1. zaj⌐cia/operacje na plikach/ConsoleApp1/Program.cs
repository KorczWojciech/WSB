﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = { "Pierwsza linijka", "druga linijka", "trzecia linijka" };
            System.IO.File.WriteAllLines(@"WriteLines1.txt", lines);
            string Text = "Skoki przez przeszkody indywidualnie były jedną z konkurencji jeździeckich na Letnich Igrzyskach \n Olimpijskich 1920. Zawody odbyły się w dniu 12 września. W zawodach uczestniczyło 25 zawodników z 6 państw.";
            System.IO.File.WriteAllText(@"WriteLines2.txt", Text);

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"WriteLines3.txt"))
            {
                foreach (string line in lines)
                {
                    if (!line.Contains("druga"))
                    {
                        file.WriteLine(line);
                    }
                }
            }
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"WriteLines3.txt", true))
            {
                file.WriteLine("Czwarta linijka");
            }

            Console.ReadKey();
        }
    }
}
